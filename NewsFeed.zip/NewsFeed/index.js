//instance of express
const express = require("express");

//server create
const app = express();

require("dotenv").config();

const PORT = process.env.PORT || 4000;

//middleware
app.use(express.json());

const newsfeedRoutes = require("./routes/newsfeeds");

//mount
app.use("/api/v1",newsfeedRoutes);

//start server at given port
app.listen(PORT,()=>{
    console.log(`server successfully started at ${PORT}`);
});


//import databse function
const dbConnect = require("./config/database");
dbConnect();

//default setup homepage
app.get("/",(req,res)=>{
    res.send(`<h1>this is your homepage bro.</h1>`);
});