//instance create
const mongoose = require("mongoose");
const Comment = require("../models/commentModel");
const Like = require("../models/likeModel");
//route handler 
const postSchema = new mongoose.Schema({

    user:{
        type:String,
        requrired: true,
    },
    title:{
        type:String,
        requrired:true,
        maxLen:50,
    },
    body:{
        type:String,
        requrired:true,
        maxLen:500,
    },
    likes:[{
        type:mongoose.Schema.Types.ObjectId,
        ref:"Like",
    }],
    comments:[{
        type:mongoose.Schema.Types.ObjectId,
        ref:"Comment",
    }]
});


//export
module.exports = mongoose.model("Post",postSchema);