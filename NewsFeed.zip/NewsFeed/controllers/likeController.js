const Post = require("../models/postModel");
const Like = require("../models/likeModel");

exports.likePost = async(req,res)=>{
    //parse post id,user
    try{
        const{post,user} = req.body;

        const like = new Like({
            post,user,
        });

        const savedLike = await like.save();

        //update post wale main
        const updatedPost = await Post.findByIdAndUpdate(post,{$push:{likes:savedLike._id}},{new:true})
        .populate("likes").exec();

        res.json({
            post:updatedPost,
        });
    }catch(err){
        return res.status(400).json({
            err:"Error while like the post",
        });
    }
}